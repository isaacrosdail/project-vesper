--
-- PostgreSQL database dump
--

\restrict f7gGc4beNDj77osELL8wfdKxHHto5NdSVUeQSPdpd7GNJrvCqOh3UCMh5ukNbA9

-- Dumped from database version 17.4 (Debian 17.4-1.pgdg120+2)
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: difficulty_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.difficulty_enum AS ENUM (
    'EASY',
    'MEDIUM',
    'HARD'
);


ALTER TYPE public.difficulty_enum OWNER TO vesper;

--
-- Name: language_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.language_enum AS ENUM (
    'PYTHON',
    'JS',
    'CPP',
    'C'
);


ALTER TYPE public.language_enum OWNER TO vesper;

--
-- Name: lcstatus_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.lcstatus_enum AS ENUM (
    'SOLVED',
    'ATTEMPTED',
    'REVIEWED'
);


ALTER TYPE public.lcstatus_enum OWNER TO vesper;

--
-- Name: priority_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.priority_enum AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH'
);


ALTER TYPE public.priority_enum OWNER TO vesper;

--
-- Name: product_category_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.product_category_enum AS ENUM (
    'FRUITS',
    'VEGETABLES',
    'LEGUMES',
    'GRAINS',
    'BAKERY',
    'DAIRY_EGGS',
    'MEATS',
    'SEAFOOD',
    'FATS_OILS',
    'SNACKS',
    'SWEETS',
    'BEVERAGES',
    'CONDIMENTS_SAUCES',
    'PROCESSED_CONVENIENCE',
    'SUPPLEMENTS'
);


ALTER TYPE public.product_category_enum OWNER TO vesper;

--
-- Name: status_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.status_enum AS ENUM (
    'EXPERIMENTAL',
    'ESTABLISHED'
);


ALTER TYPE public.status_enum OWNER TO vesper;

--
-- Name: unit_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.unit_enum AS ENUM (
    'G',
    'KG',
    'OZ',
    'LB',
    'ML',
    'L',
    'FL_OZ',
    'EA'
);


ALTER TYPE public.unit_enum OWNER TO vesper;

--
-- Name: unit_system_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.unit_system_enum AS ENUM (
    'metric',
    'imperial'
);


ALTER TYPE public.unit_system_enum OWNER TO vesper;

--
-- Name: user_lang_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.user_lang_enum AS ENUM (
    'en',
    'de'
);


ALTER TYPE public.user_lang_enum OWNER TO vesper;

--
-- Name: user_role_enum; Type: TYPE; Schema: public; Owner: vesper
--

CREATE TYPE public.user_role_enum AS ENUM (
    'OWNER',
    'ADMIN',
    'USER'
);


ALTER TYPE public.user_role_enum OWNER TO vesper;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO vesper;

--
-- Name: api_call_records; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.api_call_records (
    api_called character varying(255) NOT NULL,
    date date NOT NULL,
    call_count integer DEFAULT 0,
    id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.api_call_records OWNER TO vesper;

--
-- Name: apicallrecord_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.apicallrecord_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.apicallrecord_id_seq OWNER TO vesper;

--
-- Name: apicallrecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.apicallrecord_id_seq OWNED BY public.api_call_records.id;


--
-- Name: daily_metrics; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.daily_metrics (
    weight numeric(5,2),
    steps integer,
    calories integer,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    wake_time timestamp with time zone,
    sleep_time timestamp with time zone,
    entry_datetime timestamp with time zone NOT NULL,
    sleep_duration_minutes integer,
    CONSTRAINT ck_calories_non_negative CHECK ((calories >= 0)),
    CONSTRAINT ck_steps_non_negative CHECK ((steps >= 0)),
    CONSTRAINT ck_weight_positive CHECK ((weight > (0)::numeric))
);


ALTER TABLE public.daily_metrics OWNER TO vesper;

--
-- Name: dailyentry_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.dailyentry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dailyentry_id_seq OWNER TO vesper;

--
-- Name: dailyentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.dailyentry_id_seq OWNED BY public.daily_metrics.id;


--
-- Name: habit_completions; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.habit_completions (
    habit_id integer NOT NULL,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.habit_completions OWNER TO vesper;

--
-- Name: habits; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.habits (
    name character varying(100) NOT NULL,
    established_date timestamp with time zone,
    promotion_threshold double precision,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    status public.status_enum,
    target_frequency integer NOT NULL,
    CONSTRAINT ck_promotion_threshold_range_0_1 CHECK (((promotion_threshold IS NULL) OR ((promotion_threshold >= (0.0)::double precision) AND (promotion_threshold <= (1.0)::double precision))))
);


ALTER TABLE public.habits OWNER TO vesper;

--
-- Name: habit_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.habit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.habit_id_seq OWNER TO vesper;

--
-- Name: habit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.habit_id_seq OWNED BY public.habits.id;


--
-- Name: habit_tags; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.habit_tags (
    habit_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.habit_tags OWNER TO vesper;

--
-- Name: habitcompletion_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.habitcompletion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.habitcompletion_id_seq OWNER TO vesper;

--
-- Name: habitcompletion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.habitcompletion_id_seq OWNED BY public.habit_completions.id;


--
-- Name: leet_code_records; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.leet_code_records (
    leetcode_id integer NOT NULL,
    title character varying(200),
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    difficulty public.difficulty_enum NOT NULL,
    language public.language_enum NOT NULL,
    status public.lcstatus_enum NOT NULL
);


ALTER TABLE public.leet_code_records OWNER TO vesper;

--
-- Name: leetcoderecord_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.leetcoderecord_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.leetcoderecord_id_seq OWNER TO vesper;

--
-- Name: leetcoderecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.leetcoderecord_id_seq OWNED BY public.leet_code_records.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.products (
    name character varying(80) NOT NULL,
    barcode character varying(32),
    net_weight numeric(7,3) NOT NULL,
    unit_type public.unit_enum NOT NULL,
    calories_per_100g numeric(5,2),
    deleted_at timestamp with time zone,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    category public.product_category_enum NOT NULL,
    CONSTRAINT ck_product_calories_non_negative CHECK ((calories_per_100g >= (0)::numeric))
);


ALTER TABLE public.products OWNER TO vesper;

--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_id_seq OWNER TO vesper;

--
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.products.id;


--
-- Name: shopping_list_items; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.shopping_list_items (
    shopping_list_id integer NOT NULL,
    product_id integer NOT NULL,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    quantity_wanted integer NOT NULL,
    CONSTRAINT ck_shopping_quantity_wanted_positive CHECK ((quantity_wanted > 0))
);


ALTER TABLE public.shopping_list_items OWNER TO vesper;

--
-- Name: shopping_lists; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.shopping_lists (
    name character varying(64),
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.shopping_lists OWNER TO vesper;

--
-- Name: shoppinglist_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.shoppinglist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shoppinglist_id_seq OWNER TO vesper;

--
-- Name: shoppinglist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.shoppinglist_id_seq OWNED BY public.shopping_lists.id;


--
-- Name: shoppinglistitem_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.shoppinglistitem_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shoppinglistitem_id_seq OWNER TO vesper;

--
-- Name: shoppinglistitem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.shoppinglistitem_id_seq OWNED BY public.shopping_list_items.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.tags (
    name character varying(50) NOT NULL,
    scope character varying(20),
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tags OWNER TO vesper;

--
-- Name: tag_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.tag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tag_id_seq OWNER TO vesper;

--
-- Name: tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.tag_id_seq OWNED BY public.tags.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.tasks (
    name character varying(150) NOT NULL,
    is_done boolean,
    due_date timestamp with time zone,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    completed_at timestamp with time zone,
    is_frog boolean,
    priority public.priority_enum DEFAULT 'MEDIUM'::public.priority_enum,
    CONSTRAINT ck_frog_priority_mutually_exclusive CHECK ((((is_frog = true) AND (priority IS NULL)) OR ((is_frog = false) AND (priority IS NOT NULL)))),
    CONSTRAINT ck_task_frog_requires_due_date CHECK (((NOT is_frog) OR (due_date IS NOT NULL)))
);


ALTER TABLE public.tasks OWNER TO vesper;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_id_seq OWNER TO vesper;

--
-- Name: task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.task_id_seq OWNED BY public.tasks.id;


--
-- Name: task_tags; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.task_tags (
    task_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.task_tags OWNER TO vesper;

--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.time_entries (
    category character varying(50) NOT NULL,
    description character varying(200),
    started_at timestamp with time zone NOT NULL,
    duration_minutes integer NOT NULL,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    ended_at timestamp with time zone NOT NULL,
    CONSTRAINT ck_ended_after_started CHECK ((ended_at > started_at)),
    CONSTRAINT ck_time_entry_category_non_empty CHECK ((length((category)::text) > 0)),
    CONSTRAINT ck_time_entry_duration_positive CHECK ((duration_minutes > 0)),
    CONSTRAINT ck_timeentry_ch_time_entry_duration_positive CHECK (((duration_minutes)::double precision > (0)::double precision))
);


ALTER TABLE public.time_entries OWNER TO vesper;

--
-- Name: timeentry_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.timeentry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.timeentry_id_seq OWNER TO vesper;

--
-- Name: timeentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.timeentry_id_seq OWNED BY public.time_entries.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.transactions (
    product_id integer NOT NULL,
    price_at_scan numeric(7,2) NOT NULL,
    quantity integer NOT NULL,
    id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT ck_transaction_price_non_negative CHECK ((price_at_scan >= (0)::numeric)),
    CONSTRAINT ck_transaction_quantity_positive CHECK ((quantity > 0))
);


ALTER TABLE public.transactions OWNER TO vesper;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transaction_id_seq OWNER TO vesper;

--
-- Name: transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.transaction_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: vesper
--

CREATE TABLE public.users (
    username character varying(30) NOT NULL,
    name character varying(50),
    password_hash character varying(256) NOT NULL,
    timezone character varying(50) DEFAULT 'America/Chicago'::character varying NOT NULL,
    id integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    role public.user_role_enum DEFAULT 'USER'::public.user_role_enum NOT NULL,
    lang public.user_lang_enum DEFAULT 'en'::public.user_lang_enum NOT NULL,
    city character varying(100) DEFAULT 'Chicago'::character varying NOT NULL,
    country character varying(3) DEFAULT 'US'::character varying NOT NULL,
    units public.unit_system_enum DEFAULT 'imperial'::public.unit_system_enum NOT NULL
);


ALTER TABLE public.users OWNER TO vesper;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: vesper
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO vesper;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vesper
--

ALTER SEQUENCE public.user_id_seq OWNED BY public.users.id;


--
-- Name: api_call_records id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.api_call_records ALTER COLUMN id SET DEFAULT nextval('public.apicallrecord_id_seq'::regclass);


--
-- Name: daily_metrics id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.daily_metrics ALTER COLUMN id SET DEFAULT nextval('public.dailyentry_id_seq'::regclass);


--
-- Name: habit_completions id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habit_completions ALTER COLUMN id SET DEFAULT nextval('public.habitcompletion_id_seq'::regclass);


--
-- Name: habits id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habits ALTER COLUMN id SET DEFAULT nextval('public.habit_id_seq'::regclass);


--
-- Name: leet_code_records id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.leet_code_records ALTER COLUMN id SET DEFAULT nextval('public.leetcoderecord_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- Name: shopping_list_items id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_list_items ALTER COLUMN id SET DEFAULT nextval('public.shoppinglistitem_id_seq'::regclass);


--
-- Name: shopping_lists id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_lists ALTER COLUMN id SET DEFAULT nextval('public.shoppinglist_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tag_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.task_id_seq'::regclass);


--
-- Name: time_entries id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.time_entries ALTER COLUMN id SET DEFAULT nextval('public.timeentry_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transaction_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.alembic_version (version_num) FROM stdin;
fb4bf56d8ea0
\.


--
-- Data for Name: api_call_records; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.api_call_records (api_called, date, call_count, id, created_at, updated_at) FROM stdin;
openweathermap	2026-01-05	62	343	\N	\N
openweathermap	2026-01-02	30	267	\N	\N
openweathermap	2025-12-30	28	161	\N	\N
openweathermap	2026-01-06	7	405	\N	\N
openweathermap	2025-12-16	16	1	\N	\N
openweathermap	2026-01-08	6	412	\N	\N
openweathermap	2026-01-09	1	418	\N	\N
openweathermap	2025-12-22	57	93	\N	\N
openweathermap	2025-12-18	16	17	\N	\N
openweathermap	2025-12-28	4	150	\N	\N
openweathermap	2025-12-19	4	33	\N	\N
openweathermap	2025-12-31	20	189	\N	\N
openweathermap	2025-12-29	7	154	\N	\N
openweathermap	2025-12-21	37	56	\N	\N
openweathermap	2026-01-10	10	419	\N	\N
openweathermap	2026-01-01	58	209	\N	\N
openweathermap	2025-12-20	19	37	\N	\N
openweathermap	2026-01-03	30	297	\N	\N
openweathermap	2026-01-04	14	327	\N	\N
\.


--
-- Data for Name: daily_metrics; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.daily_metrics (weight, steps, calories, id, user_id, created_at, updated_at, wake_time, sleep_time, entry_datetime, sleep_duration_minutes) FROM stdin;
70.50	8500	2100	1	2	2026-01-03 23:28:38.009093+00	2026-01-05 05:28:38.011212+00	2026-01-04 07:00:38.009093+00	2026-01-03 23:30:38.009093+00	2025-11-23 00:00:00+00	\N
70.30	10200	2050	2	2	2026-01-04 23:28:38.009093+00	2026-01-05 05:28:38.011213+00	2026-01-04 06:45:38.009093+00	2026-01-03 23:00:38.009093+00	2025-11-23 00:00:00+00	\N
\N	1300	\N	4	2	2026-01-08 02:33:36.713094+00	2026-01-08 02:33:36.713096+00	\N	\N	2026-01-07 06:00:00+00	\N
\N	4351	\N	5	2	2026-01-08 02:33:44.054243+00	2026-01-08 02:33:44.054246+00	\N	\N	2026-01-04 06:00:00+00	\N
94.80	3600	\N	3	2	2026-01-06 03:45:06.062491+00	2026-01-08 02:34:01.075915+00	\N	\N	2026-01-05 06:00:00+00	\N
\.


--
-- Data for Name: habit_completions; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.habit_completions (habit_id, id, user_id, created_at, updated_at) FROM stdin;
1	1	2	2026-01-04 23:28:38.009093+00	2026-01-05 05:28:38.02127+00
1	2	2	2026-01-03 23:28:38.009093+00	2026-01-05 05:28:38.021272+00
1	3	2	2026-01-02 23:28:38.009093+00	2026-01-05 05:28:38.021272+00
3	7	2	2026-01-08 02:31:20.368+00	2026-01-08 02:31:20.102365+00
\.


--
-- Data for Name: habit_tags; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.habit_tags (habit_id, tag_id) FROM stdin;
2	2
1	1
3	3
\.


--
-- Data for Name: habits; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.habits (name, established_date, promotion_threshold, id, user_id, created_at, updated_at, status, target_frequency) FROM stdin;
Daily coding practice	\N	\N	1	2	2026-01-05 05:28:38.014946+00	2026-01-05 05:28:38.014947+00	\N	4
Read documentation	\N	\N	2	2	2026-01-05 05:28:38.014948+00	2026-01-05 05:28:38.014948+00	\N	4
Exercise	\N	\N	3	2	2026-01-05 05:28:38.014949+00	2026-01-05 05:28:38.014949+00	\N	4
\.


--
-- Data for Name: leet_code_records; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.leet_code_records (leetcode_id, title, id, user_id, created_at, updated_at, difficulty, language, status) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.products (name, barcode, net_weight, unit_type, calories_per_100g, deleted_at, id, user_id, created_at, updated_at, category) FROM stdin;
Steve's Apples	\N	12.000	KG	12.00	\N	1	2	2026-01-08 02:32:18.451879+00	2026-01-08 02:32:18.451881+00	GRAINS
Red Bull	\N	100.000	ML	45.00	\N	2	2	2026-01-08 02:32:40.660912+00	2026-01-08 02:32:40.660914+00	BEVERAGES
\.


--
-- Data for Name: shopping_list_items; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.shopping_list_items (shopping_list_id, product_id, id, user_id, created_at, updated_at, quantity_wanted) FROM stdin;
1	1	1	2	2026-01-08 02:32:48.837535+00	2026-01-08 02:32:48.837537+00	1
1	2	2	2	2026-01-08 02:32:51.322173+00	2026-01-08 02:32:52.562962+00	2
\.


--
-- Data for Name: shopping_lists; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.shopping_lists (name, id, user_id, created_at, updated_at) FROM stdin;
DefaultListName	1	2	2026-01-05 05:28:42.183222+00	2026-01-05 05:28:42.183224+00
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.tags (name, scope, id, user_id, created_at, updated_at) FROM stdin;
work	universal	1	2	2026-01-05 05:28:38.01867+00	2026-01-05 05:28:38.018671+00
demo	universal	2	2	2026-01-05 05:28:38.018672+00	2026-01-05 05:28:38.018673+00
health	universal	3	2	2026-01-05 05:28:38.018673+00	2026-01-05 05:28:38.018673+00
\.


--
-- Data for Name: task_tags; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.task_tags (task_id, tag_id) FROM stdin;
1	1
2	1
3	3
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.tasks (name, is_done, due_date, id, user_id, created_at, updated_at, completed_at, is_frog, priority) FROM stdin;
Review job applications	f	\N	1	2	2026-01-05 05:28:38.017194+00	2026-01-08 03:10:17.486242+00	\N	f	HIGH
Morning workout	f	\N	3	2	2026-01-05 05:28:38.017197+00	2026-01-10 04:26:47.623627+00	2026-01-10 04:26:47.409+00	f	LOW
testtime	f	\N	4	2	2026-01-10 06:36:49.917759+00	2026-01-10 06:36:49.917762+00	\N	f	MEDIUM
Update portfolio README	f	2026-01-07 23:28:38.009093+00	2	2	2026-01-05 05:28:38.017196+00	2026-01-08 03:10:11.663751+00	\N	f	MEDIUM
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.time_entries (category, description, started_at, duration_minutes, id, user_id, created_at, updated_at, ended_at) FROM stdin;
Coding	Built new feature for task module	2026-01-04 20:28:38.009093+00	90	1	2	2026-01-05 05:28:38.01375+00	2026-01-05 05:28:38.013752+00	2026-01-04 21:58:38.009093+00
Learning	Studied deployment best practices	2026-01-03 21:28:38.009093+00	60	2	2	2026-01-05 05:28:38.013752+00	2026-01-05 05:28:38.013753+00	2026-01-03 22:28:38.009093+00
Exercise	Morning run	2026-01-04 18:28:38.009093+00	30	3	2	2026-01-05 05:28:38.013753+00	2026-01-05 05:28:38.013754+00	2026-01-04 18:58:38.009093+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.transactions (product_id, price_at_scan, quantity, id, user_id, created_at, updated_at) FROM stdin;
1	1.23	2	1	2	2026-01-08 02:32:18.459644+00	2026-01-08 02:32:18.459646+00
2	1.50	2	2	2	2026-01-08 02:32:40.662942+00	2026-01-08 02:32:40.662944+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: vesper
--

COPY public.users (username, name, password_hash, timezone, id, created_at, updated_at, role, lang, city, country, units) FROM stdin;
owner	Owner	scrypt:32768:8:1$tmYbiXNPTxyWnSfA$8c53f02b3f5631ccc8e0428dc3abe5406bb89366330cb4150799135fda41aaee09a577cf2b81191c4a1fe4c5ca2511748d20c098660b9a8f832a7404931ea88b	America/Chicago	1	2026-01-05 05:28:35.699305+00	2026-01-05 05:28:35.699309+00	OWNER	en	Chicago	US	imperial
guest	Guest	scrypt:32768:8:1$52UYx1aSFa14Nlzo$db579cfbb3ddd0b1dca45c50cb1016070ba785baf52182fe20e909d001161efecc4b1f508940eff3771331db3051e89f31bacdc34800fc9576c0fe9639e85e25	America/Chicago	2	2026-01-05 05:28:38.007604+00	2026-01-05 05:28:38.007608+00	USER	en	Chicago	US	imperial
\.


--
-- Name: apicallrecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.apicallrecord_id_seq', 428, true);


--
-- Name: dailyentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.dailyentry_id_seq', 5, true);


--
-- Name: habit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.habit_id_seq', 3, true);


--
-- Name: habitcompletion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.habitcompletion_id_seq', 7, true);


--
-- Name: leetcoderecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.leetcoderecord_id_seq', 1, false);


--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.product_id_seq', 2, true);


--
-- Name: shoppinglist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.shoppinglist_id_seq', 1, true);


--
-- Name: shoppinglistitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.shoppinglistitem_id_seq', 2, true);


--
-- Name: tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.tag_id_seq', 3, true);


--
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.task_id_seq', 4, true);


--
-- Name: timeentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.timeentry_id_seq', 3, true);


--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.transaction_id_seq', 2, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vesper
--

SELECT pg_catalog.setval('public.user_id_seq', 2, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_call_records pk_apicallrecord; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.api_call_records
    ADD CONSTRAINT pk_apicallrecord PRIMARY KEY (id);


--
-- Name: daily_metrics pk_dailyentry; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.daily_metrics
    ADD CONSTRAINT pk_dailyentry PRIMARY KEY (id);


--
-- Name: habits pk_habit; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habits
    ADD CONSTRAINT pk_habit PRIMARY KEY (id);


--
-- Name: habit_tags pk_habit_tags; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habit_tags
    ADD CONSTRAINT pk_habit_tags PRIMARY KEY (habit_id, tag_id);


--
-- Name: habit_completions pk_habitcompletion; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habit_completions
    ADD CONSTRAINT pk_habitcompletion PRIMARY KEY (id);


--
-- Name: leet_code_records pk_leetcoderecord; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.leet_code_records
    ADD CONSTRAINT pk_leetcoderecord PRIMARY KEY (id);


--
-- Name: products pk_product; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT pk_product PRIMARY KEY (id);


--
-- Name: shopping_lists pk_shoppinglist; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT pk_shoppinglist PRIMARY KEY (id);


--
-- Name: shopping_list_items pk_shoppinglistitem; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT pk_shoppinglistitem PRIMARY KEY (id);


--
-- Name: tags pk_tag; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT pk_tag PRIMARY KEY (id);


--
-- Name: tasks pk_task; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT pk_task PRIMARY KEY (id);


--
-- Name: task_tags pk_task_tags; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT pk_task_tags PRIMARY KEY (task_id, tag_id);


--
-- Name: time_entries pk_timeentry; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT pk_timeentry PRIMARY KEY (id);


--
-- Name: transactions pk_transaction; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT pk_transaction PRIMARY KEY (id);


--
-- Name: users pk_user; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_user PRIMARY KEY (id);


--
-- Name: api_call_records uq_api_called_date; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.api_call_records
    ADD CONSTRAINT uq_api_called_date UNIQUE (api_called, date);


--
-- Name: api_call_records uq_apicallrecord_api_called; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.api_call_records
    ADD CONSTRAINT uq_apicallrecord_api_called UNIQUE (api_called, date);


--
-- Name: habits uq_habit_name; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habits
    ADD CONSTRAINT uq_habit_name UNIQUE (name);


--
-- Name: products uq_product_barcode; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT uq_product_barcode UNIQUE (barcode);


--
-- Name: tags uq_tag_name; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT uq_tag_name UNIQUE (name);


--
-- Name: tasks uq_task_name; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT uq_task_name UNIQUE (name);


--
-- Name: habits uq_user_habit_name; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habits
    ADD CONSTRAINT uq_user_habit_name UNIQUE (user_id, name);


--
-- Name: products uq_user_product_barcode; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT uq_user_product_barcode UNIQUE (user_id, barcode);


--
-- Name: products uq_user_product_name; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT uq_user_product_name UNIQUE (user_id, name);


--
-- Name: tags uq_user_tag_name; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT uq_user_tag_name UNIQUE (user_id, name);


--
-- Name: tasks uq_user_task_name; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT uq_user_task_name UNIQUE (user_id, name);


--
-- Name: users uq_user_username; Type: CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_user_username UNIQUE (username);


--
-- Name: ix_user_entry_datetime; Type: INDEX; Schema: public; Owner: vesper
--

CREATE INDEX ix_user_entry_datetime ON public.daily_metrics USING btree (user_id, entry_datetime);


--
-- Name: daily_metrics fk_dailyentry_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.daily_metrics
    ADD CONSTRAINT fk_dailyentry_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: habit_tags fk_habit_tags_habit_id_habits; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habit_tags
    ADD CONSTRAINT fk_habit_tags_habit_id_habits FOREIGN KEY (habit_id) REFERENCES public.habits(id);


--
-- Name: habit_tags fk_habit_tags_tag_id_tags; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habit_tags
    ADD CONSTRAINT fk_habit_tags_tag_id_tags FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: habits fk_habit_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habits
    ADD CONSTRAINT fk_habit_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: habit_completions fk_habitcompletion_habit_id_habit; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habit_completions
    ADD CONSTRAINT fk_habitcompletion_habit_id_habit FOREIGN KEY (habit_id) REFERENCES public.habits(id);


--
-- Name: habit_completions fk_habitcompletion_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.habit_completions
    ADD CONSTRAINT fk_habitcompletion_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: leet_code_records fk_leetcoderecord_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.leet_code_records
    ADD CONSTRAINT fk_leetcoderecord_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: products fk_product_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_product_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shopping_lists fk_shoppinglist_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_lists
    ADD CONSTRAINT fk_shoppinglist_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shopping_list_items fk_shoppinglistitem_product_id_product; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT fk_shoppinglistitem_product_id_product FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: shopping_list_items fk_shoppinglistitem_shopping_list_id_shoppinglist; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT fk_shoppinglistitem_shopping_list_id_shoppinglist FOREIGN KEY (shopping_list_id) REFERENCES public.shopping_lists(id);


--
-- Name: shopping_list_items fk_shoppinglistitem_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.shopping_list_items
    ADD CONSTRAINT fk_shoppinglistitem_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tags fk_tag_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT fk_tag_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: task_tags fk_task_tags_tag_id_tags; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT fk_task_tags_tag_id_tags FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: task_tags fk_task_tags_task_id_tasks; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT fk_task_tags_task_id_tasks FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- Name: tasks fk_task_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_task_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: time_entries fk_timeentry_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT fk_timeentry_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: transactions fk_transaction_product_id_product; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transaction_product_id_product FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: transactions fk_transaction_user_id_user; Type: FK CONSTRAINT; Schema: public; Owner: vesper
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transaction_user_id_user FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict f7gGc4beNDj77osELL8wfdKxHHto5NdSVUeQSPdpd7GNJrvCqOh3UCMh5ukNbA9

